/// <mls shortName="page1" project="102017" enhancement="_100554_enhancementLit" groupName="page" />

import { CollabPageElement } from '_100554_/l2/collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from '_100554_/l2/collabState';

@customElement('page1-102017')
export class Page1100000 extends CollabPageElement {
    initPage() {

    }
}

