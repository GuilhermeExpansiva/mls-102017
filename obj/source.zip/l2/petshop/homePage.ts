/// <mls shortName="homePage" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />

import { CollabPageElement } from '_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from '_100554_collabState';

@customElement('petshop--home-page-102017')
export class PageHomePage extends CollabPageElement {
    initPage() {

    }
}