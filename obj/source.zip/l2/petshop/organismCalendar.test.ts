/// <mls shortName="organismCalendar" project="102017" enhancement="_blank" folder="petshop" />

 import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];