/// <mls shortName="widget1" project="102017" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '_100554_/l2/stateLitElement';
let Widget1100000 = class Widget1100000 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget1-102017{color:rebeccapurple}`);
        this.name = 'Somebody';
    }
    render() {
        return html `<p> Hello, ${this.name} !</p>`;
    }
};
__decorate([
    property()
], Widget1100000.prototype, "name", void 0);
Widget1100000 = __decorate([
    customElement('widget1-102017')
], Widget1100000);
export { Widget1100000 };
