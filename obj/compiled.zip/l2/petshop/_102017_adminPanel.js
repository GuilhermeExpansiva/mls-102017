/// <mls shortName="adminPanel" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from '_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let PageAdminPanel = class PageAdminPanel extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`petshop--admin-panel-102017{display:flex;flex-direction:column;min-height:100vh}petshop--admin-panel-102017 header{position:fixed;top:0;width:100%;z-index:10}petshop--admin-panel-102017 aside{position:fixed;left:0;top:0;width:250px;height:100vh;background:var(--bg-primary-color);padding:var(--space-24);box-shadow:2px 0 5px var(--grey-color)}petshop--admin-panel-102017 main{margin-left:250px;margin-top:60px;padding:var(--space-24);flex:1}petshop--admin-panel-102017 footer{margin-left:250px;margin-top:auto}@media (max-width:768px){petshop--admin-panel-102017 aside{width:100%;height:auto;position:static}petshop--admin-panel-102017 main{margin-left:0;margin-top:0}petshop--admin-panel-102017 footer{margin-left:0}}`);
    }
    initPage() {
    }
};
PageAdminPanel = __decorate([
    customElement('petshop--admin-panel-102017')
], PageAdminPanel);
export { PageAdminPanel };
