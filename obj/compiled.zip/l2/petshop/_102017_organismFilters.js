var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismFilters" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    filtersTitle: 'Filtros',
    categoryLabel: 'Categoria',
    allCategories: 'Todas',
    foodCategory: 'Ração',
    toysCategory: 'Brinquedos',
    accessoriesCategory: 'Acessórios',
    minPriceLabel: 'Preço Mínimo',
    maxPriceLabel: 'Preço Máximo',
    applyFiltersButton: 'Aplicar Filtros'
};
const message_en = {
    filtersTitle: 'Filters',
    categoryLabel: 'Category',
    allCategories: 'All',
    foodCategory: 'Food',
    toysCategory: 'Toys',
    accessoriesCategory: 'Accessories',
    minPriceLabel: 'Minimum Price',
    maxPriceLabel: 'Maximum Price',
    applyFiltersButton: 'Apply Filters'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const inMemoryDb = {
    filters: {
        categories: ['Todas', 'Ração', 'Brinquedos', 'Acessórios'],
        defaultMinPrice: 0,
        defaultMaxPrice: 1000
    }
};
let organismFilters = class organismFilters extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-filters-102017{background-color:var(--bg-secondary-color);padding:var(--space-16);border-right:1px solid var(--grey-color)}petshop--organism-filters-102017 .filter-title{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16)}petshop--organism-filters-102017 .filter-group{margin-bottom:var(--space-24)}petshop--organism-filters-102017 .filter-group label{display:block;font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8)}petshop--organism-filters-102017 .filter-group select,petshop--organism-filters-102017 .filter-group input{width:100%;padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px;font-size:var(--font-size-16)}petshop--organism-filters-102017 .filter-group select:focus,petshop--organism-filters-102017 .filter-group input:focus{border-color:var(--active-color);outline:none}petshop--organism-filters-102017 .apply-filters{background-color:var(--text-primary-color);color:var(--bg-primary-color);border:none;padding:var(--space-16);width:100%;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);border-radius:4px;cursor:pointer;transition:background-color var(--transition-normal)}petshop--organism-filters-102017 .apply-filters:hover{background-color:var(--text-primary-color-hover)}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchFilters();
        this.updateStatesFromFilters(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch available filter options for products.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.filters
     */
    mockFetchFilters() {
        return {
            category: '',
            minPrice: inMemoryDb.filters.defaultMinPrice,
            maxPrice: inMemoryDb.filters.defaultMaxPrice
        };
    }
    /**
     * endpoint-intent: I need an endpoint to apply filters and retrieve filtered products.
     * method: POST
     * notes: client-only mock, updates inMemoryDb and simulates filtering
     */
    mockApplyFilters(filters) {
        // Simulate applying filters, perhaps update inMemoryDb or just return
        return filters;
    }
    updateStatesFromFilters(resp) {
        setState('ui.petshop.organismFilters', resp);
        this.appliedFilters = resp;
    }
    handleApplyFilters(e) {
        e.preventDefault();
        const category = this.shadowRoot?.getElementById('categoria')?.value || '';
        const minPrice = parseFloat(this.shadowRoot?.getElementById('preco-min')?.value || '0');
        const maxPrice = parseFloat(this.shadowRoot?.getElementById('preco-max')?.value || '1000');
        const filters = { category, minPrice, maxPrice };
        const resp = this.mockApplyFilters(filters);
        this.updateStatesFromFilters(resp);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="filter-title" id="petshop--filters-102017-1">${this.i18n.filtersTitle}</div>
<div class="filter-group" id="petshop--filters-102017-2">
<label for="categoria" id="petshop--filters-102017-3">${this.i18n.categoryLabel}</label>
<select id="categoria" .value=${this.appliedFilters?.category || ''}>
<option value="" id="petshop--filters-102017-4">${this.i18n.allCategories}</option>
${inMemoryDb.filters.categories.slice(1).map(cat => html `<option value=${cat.toLowerCase()}>${cat}</option>`)}
</select>
</div>
<div class="filter-group" id="petshop--filters-102017-8">
<label for="preco-min" id="petshop--filters-102017-9">${this.i18n.minPriceLabel}</label>
<input type="number" id="preco-min" placeholder="0" .value=${this.appliedFilters?.minPrice?.toString() || '0'}>
</div>
<div class="filter-group" id="petshop--filters-102017-10">
<label for="preco-max" id="petshop--filters-102017-11">${this.i18n.maxPriceLabel}</label>
<input type="number" id="preco-max" placeholder="1000" .value=${this.appliedFilters?.maxPrice?.toString() || '1000'}>
</div>
<button class="apply-filters" id="petshop--filters-102017-12" @click=${this.handleApplyFilters}>${this.i18n.applyFiltersButton}</button>
`;
    }
};
__decorate([
    state()
], organismFilters.prototype, "appliedFilters", void 0);
organismFilters = __decorate([
    customElement('petshop--organism-filters-102017')
], organismFilters);
export { organismFilters };
