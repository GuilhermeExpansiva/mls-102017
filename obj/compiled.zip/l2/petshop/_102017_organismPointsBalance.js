var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismPointsBalance" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    balanceTitle: 'Saldo de Pontos',
    pointsDisplay: 'Você possui {points} pontos acumulados.',
    pointsInfo: 'Ganhe 1 ponto por real gasto em compras.'
};
const message_en = {
    balanceTitle: 'Points Balance',
    pointsDisplay: 'You have {points} accumulated points.',
    pointsInfo: 'Earn 1 point per real spent on purchases.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
const inMemoryDb = {
    points: 1500
};
let organismPointsBalance = class organismPointsBalance extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-points-balance-102017 .balance-container{text-align:center;margin:var(--space-32) 0}petshop--organism-points-balance-102017 .points-display{font-size:var(--font-size-24);color:var(--text-primary-color)}petshop--organism-points-balance-102017 .points-number{font-weight:var(--font-weight-bold);color:var(--text-secondary-color)}petshop--organism-points-balance-102017 .points-info{font-size:var(--font-size-16);color:var(--grey-color)}@media (max-width:544px){petshop--organism-points-balance-102017 .balance-container{margin:var(--space-16) 0}petshop--organism-points-balance-102017 .points-display{font-size:var(--font-size-20)}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchPoints();
        this.updateStatesFromPoints(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch the user's loyalty points balance.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.points
     */
    mockFetchPoints() {
        return { points: inMemoryDb.points };
    }
    updateStatesFromPoints(resp) {
        setState('ui.petshop.organismPointsBalance', resp);
        this.pointsResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="balance-container" id="petshop--points-balance-102017-1">
      <h2 id="petshop--points-balance-102017-2">${this.i18n.balanceTitle}</h2>
      <p class="points-display" id="petshop--points-balance-102017-3">${this.i18n.pointsDisplay.replace('{points}', this.pointsResponse?.points.toString() || '0')}</p>
      <p class="points-info" id="petshop--points-balance-102017-5">${this.i18n.pointsInfo}</p>
    </div>`;
    }
};
__decorate([
    state()
], organismPointsBalance.prototype, "pointsResponse", void 0);
organismPointsBalance = __decorate([
    customElement('petshop--organism-points-balance-102017')
], organismPointsBalance);
export { organismPointsBalance };
