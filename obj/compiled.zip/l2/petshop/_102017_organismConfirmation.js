var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismConfirmation" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    confirmationTitle: 'Confirmação do Agendamento',
    serviceLabel: 'Serviço:',
    dateLabel: 'Data:',
    timeLabel: 'Horário:',
    priceLabel: 'Preço:',
    confirmButton: 'Confirmar Agendamento',
    notification: 'Você receberá uma confirmação por e-mail e SMS.'
};
const message_en = {
    confirmationTitle: 'Appointment Confirmation',
    serviceLabel: 'Service:',
    dateLabel: 'Date:',
    timeLabel: 'Time:',
    priceLabel: 'Price:',
    confirmButton: 'Confirm Appointment',
    notification: 'You will receive a confirmation by email and SMS.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const inMemoryDb = {
    appointment: {
        service: 'Banho',
        date: '15 de Novembro de 2025',
        time: '10:00',
        price: 'R$ 50,00'
    }
};
let organismConfirmation = class organismConfirmation extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-confirmation-102017 .confirmation-container{background-color:var(--bg-primary-color);padding:var(--space-24);border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);margin-top:var(--space-24)}petshop--organism-confirmation-102017 .confirmation-header{font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16)}petshop--organism-confirmation-102017 .summary{margin-bottom:var(--space-24)}petshop--organism-confirmation-102017 .summary-item{display:flex;justify-content:space-between;margin-bottom:var(--space-8)}petshop--organism-confirmation-102017 .summary-label{font-weight:var(--font-weight-bold);color:var(--text-primary-color)}petshop--organism-confirmation-102017 .summary-value{color:var(--text-secondary-color)}petshop--organism-confirmation-102017 .confirm-button{background-color:var(--success-color);color:var(--bg-primary-color);padding:var(--space-16) var(--space-32);border:none;border-radius:4px;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer}petshop--organism-confirmation-102017 .confirm-button:hover{background-color:var(--success-color-hover)}petshop--organism-confirmation-102017 .notification{margin-top:var(--space-16);font-size:var(--font-size-16);color:var(--info-color)}@media (max-width:768px){petshop--organism-confirmation-102017 .summary-item{flex-direction:column}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchAppointment();
        this.updateStatesFromAppointment(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch the current appointment details for confirmation.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.appointment
     */
    mockFetchAppointment() {
        return inMemoryDb.appointment;
    }
    updateStatesFromAppointment(resp) {
        setState('ui.petshop.organismConfirmation.appointment', resp);
        this.appointmentResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="confirmation-container" id="petshop--confirmation-102017-1">
      <h2 class="confirmation-header" id="petshop--confirmation-102017-2">${this.i18n.confirmationTitle}</h2>
      <div class="summary" id="petshop--confirmation-102017-3">
        <div class="summary-item" id="petshop--confirmation-102017-4">
          <span class="summary-label" id="petshop--confirmation-102017-5">${this.i18n.serviceLabel}</span>
          <span class="summary-value" id="petshop--confirmation-102017-6">${this.appointmentResponse?.service}</span>
        </div>
        <div class="summary-item" id="petshop--confirmation-102017-7">
          <span class="summary-label" id="petshop--confirmation-102017-8">${this.i18n.dateLabel}</span>
          <span class="summary-value" id="petshop--confirmation-102017-9">${this.appointmentResponse?.date}</span>
        </div>
        <div class="summary-item" id="petshop--confirmation-102017-10">
          <span class="summary-label" id="petshop--confirmation-102017-11">${this.i18n.timeLabel}</span>
          <span class="summary-value" id="petshop--confirmation-102017-12">${this.appointmentResponse?.time}</span>
        </div>
        <div class="summary-item" id="petshop--confirmation-102017-13">
          <span class="summary-label" id="petshop--confirmation-102017-14">${this.i18n.priceLabel}</span>
          <span class="summary-value" id="petshop--confirmation-102017-15">${this.appointmentResponse?.price}</span>
        </div>
      </div>
      <button class="confirm-button" id="petshop--confirmation-102017-16">${this.i18n.confirmButton}</button>
      <p class="notification" id="petshop--confirmation-102017-17">${this.i18n.notification}</p>
    </div>`;
    }
};
__decorate([
    state()
], organismConfirmation.prototype, "appointmentResponse", void 0);
organismConfirmation = __decorate([
    customElement('petshop--organism-confirmation-102017')
], organismConfirmation);
export { organismConfirmation };
