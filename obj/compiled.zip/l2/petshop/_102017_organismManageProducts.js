var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismManageProducts" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    manageProducts: 'Gerenciar Produtos',
    name: 'Nome',
    category: 'Categoria',
    price: 'Preço',
    stock: 'Estoque',
    actions: 'Ações',
    edit: 'Editar',
    remove: 'Remover',
    addProduct: 'Adicionar Produto'
};
const message_en = {
    manageProducts: 'Manage Products',
    name: 'Name',
    category: 'Category',
    price: 'Price',
    stock: 'Stock',
    actions: 'Actions',
    edit: 'Edit',
    remove: 'Remove',
    addProduct: 'Add Product'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const inMemoryDb = {
    products: [
        { id: 1, name: 'Ração para Cães', category: 'Alimentação', price: 45.00, stock: 50 },
        { id: 2, name: 'Brinquedo para Gatos', category: 'Brinquedos', price: 15.00, stock: 30 }
    ]
};
let organismManageProducts = class organismManageProducts extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-manage-products-102017 .manage-container h2{color:var(--text-primary-color);font-size:var(--font-size-24);margin-bottom:var(--space-24)}petshop--organism-manage-products-102017 .manage-container .products-table{width:100%;border-collapse:collapse}petshop--organism-manage-products-102017 .manage-container .products-table th,petshop--organism-manage-products-102017 .manage-container .products-table td{padding:var(--space-16);border:1px solid var(--grey-color);text-align:left}petshop--organism-manage-products-102017 .manage-container .products-table th{background:var(--bg-secondary-color);color:var(--text-primary-color)}petshop--organism-manage-products-102017 .manage-container .products-table button{background:var(--active-color);color:var(--bg-primary-color);border:none;padding:var(--space-8) var(--space-16);cursor:pointer}petshop--organism-manage-products-102017 .manage-container .products-table button:hover{background:var(--active-color-hover)}petshop--organism-manage-products-102017 .manage-container .add-product-btn{margin-top:var(--space-24);background:var(--success-color);color:var(--bg-primary-color);border:none;padding:var(--space-16);font-size:var(--font-size-16);cursor:pointer}petshop--organism-manage-products-102017 .manage-container .add-product-btn:hover{background:var(--success-color-hover)}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchProducts();
        this.updateStatesFromProducts(resp);
    }
    /**
     * endpoint-intent: preciso de um endpoint para buscar a lista de produtos
     * method: GET
     * notes: usado por este organismo para listar produtos na tela
     */
    mockFetchProducts() {
        return { products: inMemoryDb.products };
    }
    updateStatesFromProducts(resp) {
        setState("ui.petshop.organismManageProducts", resp);
        this.productsResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="manage-container" id="petshop--manage-products-102017-1">
      <h2 id="petshop--manage-products-102017-2">${this.i18n.manageProducts}</h2>
      <table class="products-table" id="petshop--manage-products-102017-3">
        <thead id="petshop--manage-products-102017-4">
          <tr id="petshop--manage-products-102017-5">
            <th id="petshop--manage-products-102017-6">${this.i18n.name}</th>
            <th id="petshop--manage-products-102017-7">${this.i18n.category}</th>
            <th id="petshop--manage-products-102017-8">${this.i18n.price}</th>
            <th id="petshop--manage-products-102017-9">${this.i18n.stock}</th>
            <th id="petshop--manage-products-102017-10">${this.i18n.actions}</th>
          </tr>
        </thead>
        <tbody id="petshop--manage-products-102017-11">
          ${this.productsResponse?.products.map(product => html `
            <tr id="petshop--manage-products-102017-12-${product.id}">
              <td id="petshop--manage-products-102017-13-${product.id}">${product.name}</td>
              <td id="petshop--manage-products-102017-14-${product.id}">${product.category}</td>
              <td id="petshop--manage-products-102017-15-${product.id}">R$ ${product.price.toFixed(2)}</td>
              <td id="petshop--manage-products-102017-16-${product.id}">${product.stock}</td>
              <td id="petshop--manage-products-102017-17-${product.id}"><button id="petshop--manage-products-102017-18-${product.id}">${this.i18n.edit}</button> <button id="petshop--manage-products-102017-19-${product.id}">${this.i18n.remove}</button></td>
            </tr>
          `)}
        </tbody>
      </table>
      <button class="add-product-btn" id="petshop--manage-products-102017-28">${this.i18n.addProduct}</button>
    </div>`;
    }
};
__decorate([
    state()
], organismManageProducts.prototype, "productsResponse", void 0);
organismManageProducts = __decorate([
    customElement('petshop--organism-manage-products-102017')
], organismManageProducts);
export { organismManageProducts };
