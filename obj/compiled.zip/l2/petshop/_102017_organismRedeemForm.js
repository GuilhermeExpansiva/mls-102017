var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismRedeemForm" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    redeemTitle: 'Resgatar Recompensa',
    selectReward: 'Selecione a recompensa:',
    currentBalance: 'Saldo atual:',
    confirmRedeem: 'Confirmar Resgate',
    validationMsg: 'Certifique-se de ter pontos suficientes antes de resgatar.',
    insufficientPoints: 'Pontos insuficientes para resgatar esta recompensa.',
    redeemSuccess: 'Resgate realizado com sucesso!'
};
const message_en = {
    redeemTitle: 'Redeem Reward',
    selectReward: 'Select the reward:',
    currentBalance: 'Current balance:',
    confirmRedeem: 'Confirm Redeem',
    validationMsg: 'Make sure you have enough points before redeeming.',
    insufficientPoints: 'Insufficient points to redeem this reward.',
    redeemSuccess: 'Redeem successful!'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const inMemoryDb = {
    rewards: [
        { id: 'discount10', name: 'Desconto de 10%', points: 100 },
        { id: 'brinde', name: 'Brinde: Brinquedo', points: 200 },
        { id: 'discount20', name: 'Desconto de 20% em serviços', points: 300 }
    ],
    userBalance: 1500
};
let organismRedeemForm = class organismRedeemForm extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-redeem-form-102017 .redeem-container{max-width:600px;margin:0 auto;padding:var(--space-32);border:1px solid var(--grey-color);border-radius:8px;background:var(--bg-secondary-color-lighter)}petshop--organism-redeem-form-102017 .redeem-form{display:flex;flex-direction:column}petshop--organism-redeem-form-102017 .redeem-form label{margin-bottom:var(--space-8);font-weight:var(--font-weight-bold);color:var(--text-primary-color)}petshop--organism-redeem-form-102017 .redeem-form select{margin-bottom:var(--space-16);padding:var(--space-8);border:1px solid var(--grey-color);border-radius:4px}petshop--organism-redeem-form-102017 .balance-check{font-size:var(--font-size-16);color:var(--text-secondary-color);margin-bottom:var(--space-16)}petshop--organism-redeem-form-102017 .submit-btn{background:var(--active-color);color:var(--bg-primary-color);border:none;padding:var(--space-16);border-radius:4px;cursor:pointer;font-size:var(--font-size-16);transition:background var(--transition-normal)}petshop--organism-redeem-form-102017 .submit-btn:hover{background:var(--active-color-hover)}petshop--organism-redeem-form-102017 .validation-msg{margin-top:var(--space-16);font-size:var(--font-size-16);color:var(--warning-color)}@media (max-width:544px){petshop--organism-redeem-form-102017 .redeem-container{padding:var(--space-16)}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchRedeemData();
        this.updateStatesFromRedeem(resp);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="redeem-container" id="petshop--redeem-form-102017-1">
      <h2 id="petshop--redeem-form-102017-2">${this.i18n.redeemTitle}</h2>
      <form class="redeem-form" id="petshop--redeem-form-102017-3" @submit="${this.handleSubmit}">
        <label for="reward-select" id="petshop--redeem-form-102017-4">${this.i18n.selectReward}</label>
        <select id="reward-select" name="reward" id="petshop--redeem-form-102017-5">
          ${this.redeemResponse?.rewards.map(reward => html `<option value="${reward.id}">${reward.name} (${reward.points} pontos)</option>`)}
        </select>
        <p class="balance-check" id="petshop--redeem-form-102017-8">${this.i18n.currentBalance} ${this.redeemResponse?.userBalance} pontos</p>
        <button type="submit" class="submit-btn" id="petshop--redeem-form-102017-9">${this.i18n.confirmRedeem}</button>
      </form>
      <p class="validation-msg" id="petshop--redeem-form-102017-10">${this.i18n.validationMsg}</p>
    </div>`;
    }
    /**
     * endpoint-intent: I need an endpoint to fetch available rewards and user balance.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb
     */
    mockFetchRedeemData() {
        return inMemoryDb;
    }
    /**
     * endpoint-intent: I need an endpoint to process reward redemption.
     * method: POST
     * notes: client-only mock, updates inMemoryDb and state
     */
    mockRedeemReward(request) {
        const reward = inMemoryDb.rewards.find(r => r.id === request.rewardId);
        if (!reward || inMemoryDb.userBalance < reward.points) {
            return false;
        }
        inMemoryDb.userBalance -= reward.points;
        return true;
    }
    updateStatesFromRedeem(resp) {
        setState("ui.petshop.organismRedeemForm", resp);
        this.redeemResponse = resp;
    }
    handleSubmit(e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);
        const rewardId = formData.get('reward');
        const success = this.mockRedeemReward({ rewardId });
        if (success) {
            alert(this.i18n.redeemSuccess);
            const resp = this.mockFetchRedeemData();
            this.updateStatesFromRedeem(resp);
        }
        else {
            alert(this.i18n.insufficientPoints);
        }
    }
};
__decorate([
    state()
], organismRedeemForm.prototype, "redeemResponse", void 0);
organismRedeemForm = __decorate([
    customElement('petshop--organism-redeem-form-102017')
], organismRedeemForm);
export { organismRedeemForm };
