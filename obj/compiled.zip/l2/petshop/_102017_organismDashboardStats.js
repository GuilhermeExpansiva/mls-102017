var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismDashboardStats" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
const inMemoryDb = {
    stats: {
        totalSales: 50000,
        todayAppointments: 25,
        activeClients: 1200,
        stockProducts: 150
    }
};
/// **collab_i18n_start**
const message_pt = {
    dashboardStatsTitle: 'Estatísticas do Dashboard',
    totalSales: 'Vendas Totais',
    todayAppointments: 'Agendamentos Hoje',
    activeClients: 'Clientes Ativos',
    stockProducts: 'Produtos em Estoque'
};
const message_en = {
    dashboardStatsTitle: 'Dashboard Statistics',
    totalSales: 'Total Sales',
    todayAppointments: 'Today Appointments',
    activeClients: 'Active Clients',
    stockProducts: 'Products in Stock'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let organismDashboardStats = class organismDashboardStats extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-dashboard-stats-102017 .stats-container{display:flex;flex-wrap:wrap;gap:var(--space-24)}petshop--organism-dashboard-stats-102017 .stats-container h2{width:100%;color:var(--text-primary-color);font-size:var(--font-size-24)}petshop--organism-dashboard-stats-102017 .stats-container .stat-item{flex:1 1 200px;background:var(--bg-secondary-color);padding:var(--space-16);border-radius:4px}petshop--organism-dashboard-stats-102017 .stats-container .stat-item h3{color:var(--text-secondary-color);font-size:var(--font-size-16)}petshop--organism-dashboard-stats-102017 .stats-container .stat-item p{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color)}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchStats();
        this.updateStatesFromStats(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch dashboard statistics.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.stats
     */
    mockFetchStats() {
        return inMemoryDb.stats;
    }
    updateStatesFromStats(resp) {
        setState("ui.petshop.organismDashboardStats", resp);
        this.statsResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="stats-container" id="petshop--dashboard-stats-102017-1">
<h2 id="petshop--dashboard-stats-102017-2">${this.i18n.dashboardStatsTitle}</h2>
<div class="stat-item" id="petshop--dashboard-stats-102017-3">
<h3 id="petshop--dashboard-stats-102017-4">${this.i18n.totalSales}</h3>
<p id="petshop--dashboard-stats-102017-5">R$ ${this.statsResponse?.totalSales.toLocaleString('pt-BR', { minimumFractionDigits: 2 })},00</p>
</div>
<div class="stat-item" id="petshop--dashboard-stats-102017-6">
<h3 id="petshop--dashboard-stats-102017-7">${this.i18n.todayAppointments}</h3>
<p id="petshop--dashboard-stats-102017-8">${this.statsResponse?.todayAppointments}</p>
</div>
<div class="stat-item" id="petshop--dashboard-stats-102017-9">
<h3 id="petshop--dashboard-stats-102017-10">${this.i18n.activeClients}</h3>
<p id="petshop--dashboard-stats-102017-11">${this.statsResponse?.activeClients.toLocaleString('pt-BR')}</p>
</div>
<div class="stat-item" id="petshop--dashboard-stats-102017-12">
<h3 id="petshop--dashboard-stats-102017-13">${this.i18n.stockProducts}</h3>
<p id="petshop--dashboard-stats-102017-14">${this.statsResponse?.stockProducts}</p>
</div>
</div>
`;
    }
};
__decorate([
    state()
], organismDashboardStats.prototype, "statsResponse", void 0);
organismDashboardStats = __decorate([
    customElement('petshop--organism-dashboard-stats-102017')
], organismDashboardStats);
export { organismDashboardStats };
