var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismProductCategories" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    categoriesTitle: 'Categorias de Produtos',
    viewProducts: 'Ver produtos'
};
const message_en = {
    categoriesTitle: 'Product Categories',
    viewProducts: 'View products'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
const inMemoryDb = {
    categories: [
        {
            id: 1,
            name: 'Ração',
            imageUrl: 'https://images.unsplash.com/photo-1761486691834-cd4925ad60b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBmb29kJTIwYmFnc3xlbnwwfHx8fDE3NjI3OTUwMzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
            alt: 'Ração para pets',
            link: '#'
        },
        {
            id: 2,
            name: 'Brinquedos',
            imageUrl: 'https://images.unsplash.com/photo-1734526742079-026fa3b65082?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjB0b3lzJTIwYXNzb3J0bWVudHxlbnwwfHx8fDE3NjI3OTUwMzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
            alt: 'Brinquedos para pets',
            link: '#'
        },
        {
            id: 3,
            name: 'Acessórios',
            imageUrl: 'https://images.unsplash.com/photo-1705147293254-1d8048b14797?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxwZXQlMjBhY2Nlc3NvcmllcyUyMGxpa2UlMjBjb2xsYXJzJTIwYW5kJTIwYmVkc3xlbnwwfHx8fDE3NjI3OTUwMzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
            alt: 'Acessórios para pets',
            link: '#'
        }
    ]
};
let organismProductCategories = class organismProductCategories extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-product-categories-102017 .categories-container{padding:var(--space-32);background-color:var(--bg-primary-color)}petshop--organism-product-categories-102017 .categories-title{font-size:var(--font-size-40);font-weight:var(--font-weight-bold);color:var(--text-primary-color);text-align:center;margin-bottom:var(--space-24)}petshop--organism-product-categories-102017 .categories-grid{display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:var(--space-24)}petshop--organism-product-categories-102017 .category-item{text-align:center;padding:var(--space-16);background-color:var(--bg-secondary-color);border-radius:8px;transition:box-shadow var(--transition-normal)}petshop--organism-product-categories-102017 .category-item:hover{box-shadow:0 4px 8px rgba(0,0,0,0.1)}petshop--organism-product-categories-102017 .category-image{width:100%;height:150px;object-fit:cover;border-radius:4px;margin-bottom:var(--space-16)}petshop--organism-product-categories-102017 .category-name{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-8)}petshop--organism-product-categories-102017 .category-link{text-decoration:none;color:var(--link-color);font-weight:var(--font-weight-normal)}petshop--organism-product-categories-102017 .category-link:hover{color:var(--link-color-hover)}@media (max-width:768px){petshop--organism-product-categories-102017 .categories-grid{grid-template-columns:repeat(auto-fit, minmax(150px, 1fr))}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchCategories();
        this.updateStatesFromCategories(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch product categories.
     * method: GET
     * notes: used by this organism to populate the categories list.
     */
    mockFetchCategories() {
        return { categories: inMemoryDb.categories };
    }
    updateStatesFromCategories(resp) {
        setState('ui.petshop.organismProductCategories', resp);
        this.categoriesResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="categories-container" id="petshop--product-categories-102017-1">
      <h2 class="categories-title" id="petshop--product-categories-102017-2">${this.i18n.categoriesTitle}</h2>
      <div class="categories-grid" id="petshop--product-categories-102017-3">
        ${this.categoriesResponse?.categories.map((category, index) => html `
          <div class="category-item" id="petshop--product-categories-102017-${4 + index * 4}">
            <img src="${category.imageUrl}" alt="${category.alt}" class="category-image" id="petshop--product-categories-102017-${5 + index * 4}">
            <h3 class="category-name" id="petshop--product-categories-102017-${6 + index * 4}">${category.name}</h3>
            <a href="${category.link}" class="category-link" id="petshop--product-categories-102017-${7 + index * 4}">${this.i18n.viewProducts}</a>
          </div>
        `)}
      </div>
    </div>`;
    }
};
__decorate([
    state()
], organismProductCategories.prototype, "categoriesResponse", void 0);
organismProductCategories = __decorate([
    customElement('petshop--organism-product-categories-102017')
], organismProductCategories);
export { organismProductCategories };
