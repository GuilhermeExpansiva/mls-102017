var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismCalendar" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    selectDateTime: 'Selecione Data e Horário'
};
const message_en = {
    selectDateTime: 'Select Date and Time'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const inMemoryDb = {
    availability: {
        dates: [1, 2, 4, 5, 7, 8, 10, 11, 13, 14, 16, 17, 19, 20, 22, 23, 25, 26, 28, 29, 31],
        times: ['09:00', '10:00', '14:00', '15:00']
    }
};
let organismCalendar = class organismCalendar extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-calendar-102017 .calendar-container{background-color:var(--bg-primary-color);padding:var(--space-24);border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}petshop--organism-calendar-102017 .calendar-header{font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16)}petshop--organism-calendar-102017 .calendar-grid{display:grid;grid-template-columns:repeat(7, 1fr);gap:var(--space-8)}petshop--organism-calendar-102017 .day{padding:var(--space-16);text-align:center;border:1px solid var(--grey-color);cursor:pointer}petshop--organism-calendar-102017 .day:hover{background-color:var(--bg-secondary-color)}petshop--organism-calendar-102017 .day.available{background-color:var(--success-color);color:var(--bg-primary-color)}petshop--organism-calendar-102017 .day.selected{background-color:var(--active-color);color:var(--bg-primary-color)}petshop--organism-calendar-102017 .time-slots{margin-top:var(--space-24);display:flex;flex-wrap:wrap;gap:var(--space-8)}petshop--organism-calendar-102017 .time-slot{padding:var(--space-8) var(--space-16);border:1px solid var(--grey-color);border-radius:4px;cursor:pointer}petshop--organism-calendar-102017 .time-slot:hover{background-color:var(--bg-secondary-color)}petshop--organism-calendar-102017 .time-slot.available{background-color:var(--success-color);color:var(--bg-primary-color)}petshop--organism-calendar-102017 .time-slot.selected{background-color:var(--active-color);color:var(--bg-primary-color)}@media (max-width:768px){petshop--organism-calendar-102017 .calendar-grid{grid-template-columns:repeat(3, 1fr)}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchAvailability();
        this.updateStatesFromAvailability(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch available dates and times for scheduling.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.availability
     */
    mockFetchAvailability() {
        return inMemoryDb.availability;
    }
    updateStatesFromAvailability(resp) {
        setState('ui.petshop.organismCalendar.availability', resp);
        this.availabilityResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="calendar-container" id="petshop--calendar-102017-1">
      <h2 class="calendar-header" id="petshop--calendar-102017-2">${this.i18n.selectDateTime}</h2>
      <div class="calendar-grid" id="petshop--calendar-102017-3">
        ${Array.from({ length: 31 }, (_, i) => i + 1).map(day => html `<div class="day ${this.availabilityResponse?.dates.includes(day) ? 'available' : ''}" id="petshop--calendar-102017-${4 + day}">${day}</div>`)}
      </div>
      <div class="time-slots" id="petshop--calendar-102017-35">
        ${this.availabilityResponse?.times.map(time => html `<div class="time-slot available">${time}</div>`)}
      </div>
    </div>`;
    }
};
__decorate([
    state()
], organismCalendar.prototype, "availabilityResponse", void 0);
organismCalendar = __decorate([
    customElement('petshop--organism-calendar-102017')
], organismCalendar);
export { organismCalendar };
