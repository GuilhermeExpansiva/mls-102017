var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismNav" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
// No static texts to translate in this organism, as all are dynamic from mock
};
const message_en = {
// No static texts to translate in this organism, as all are dynamic from mock
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const inMemoryDb = {
    nav: {
        logo: "PetShop Amigo",
        menuItems: [
            { icon: "🏠", text: "Início", href: "#" },
            { icon: "📦", text: "Catálogo", href: "#" },
            { icon: "📅", text: "Agendamento", href: "#" },
            { icon: "⭐", text: "Fidelidade", href: "#" },
            { icon: "📝", text: "Blog", href: "#" }
        ]
    }
};
let organismNav = class organismNav extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-nav-102017 .nav-container{display:flex;justify-content:space-between;align-items:center;padding:var(--space-16);background-color:var(--bg-primary-color);border-bottom:1px solid var(--grey-color)}petshop--organism-nav-102017 .nav-logo{font-size:var(--font-size-24);font-weight:var(--font-weight-bold);color:var(--text-primary-color)}petshop--organism-nav-102017 .nav-menu{display:flex;list-style:none;margin:0;padding:0}petshop--organism-nav-102017 .nav-item{margin-left:var(--space-24)}petshop--organism-nav-102017 .nav-link{text-decoration:none;color:var(--text-primary-color);font-size:var(--font-size-16);transition:color var(--transition-normal)}petshop--organism-nav-102017 .nav-link:hover{color:var(--text-primary-color-hover)}petshop--organism-nav-102017 .nav-icon{margin-right:var(--space-8)}@media (max-width:768px){petshop--organism-nav-102017 .nav-container{flex-direction:column;align-items:flex-start}petshop--organism-nav-102017 .nav-menu{flex-direction:column;width:100%;margin-top:var(--space-16)}petshop--organism-nav-102017 .nav-item{margin-left:0;margin-bottom:var(--space-8)}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchNavData();
        this.updateStatesFromNav(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch navigation data for the petshop site.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.nav
     */
    mockFetchNavData() {
        return inMemoryDb.nav;
    }
    updateStatesFromNav(resp) {
        setState("ui.petshop.organismNav", resp);
        this.navData = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="nav-container" id="petshop--nav-102017-1">
      <div class="nav-logo" id="petshop--nav-102017-2">${this.navData?.logo}</div>
      <ul class="nav-menu" id="petshop--nav-102017-3">
        ${this.navData?.menuItems.map((item, index) => html `
          <li class="nav-item" id="petshop--nav-102017-${4 + index * 4}">
            <a href="${item.href}" class="nav-link" id="petshop--nav-102017-${5 + index * 4}">
              <span class="nav-icon" id="petshop--nav-102017-${6 + index * 4}">${item.icon}</span>${item.text}
            </a>
          </li>
        `)}
      </ul>
    </div>`;
    }
};
__decorate([
    state()
], organismNav.prototype, "navData", void 0);
organismNav = __decorate([
    customElement('petshop--organism-nav-102017')
], organismNav);
export { organismNav };
