var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismServiceHighlights" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    title: 'Destaques de Serviços',
    cta: 'Agendar Agora'
};
const message_en = {
    title: 'Service Highlights',
    cta: 'Schedule Now'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
const inMemoryDb = {
    services: [
        {
            name: 'Banho e Tosa',
            description: 'Deixe seu pet limpo e estiloso com nossos serviços profissionais.',
            imageUrl: 'https://images.unsplash.com/photo-1647002380358-fc70ed2f04e0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxkb2clMjBnZXR0aW5nJTIwYSUyMGJhdGglMjBhbmQlMjBncm9vbWluZ3xlbnwwfHx8fDE3NjI3OTUwMzF8MA&ixlib=rb-4.1.0&q=80&w=1080'
        },
        {
            name: 'Consulta Veterinária',
            description: 'Cuidado completo com veterinários parceiros.',
            imageUrl: 'https://images.unsplash.com/photo-1733783489145-f3d3ee7a9ccf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJpYW4lMjBleGFtaW5pbmclMjBhJTIwcGV0fGVufDB8fHx8MTc2Mjc5NTAzMXww&ixlib=rb-4.1.0&q=80&w=1080'
        }
    ]
};
let organismServiceHighlights = class organismServiceHighlights extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-service-highlights-102017 .services-container{padding:var(--space-32);background-color:var(--bg-secondary-color)}petshop--organism-service-highlights-102017 .services-title{font-size:var(--font-size-40);font-weight:var(--font-weight-bold);color:var(--text-primary-color);text-align:center;margin-bottom:var(--space-24)}petshop--organism-service-highlights-102017 .services-grid{display:grid;grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));gap:var(--space-24)}petshop--organism-service-highlights-102017 .service-item{text-align:center;padding:var(--space-16);background-color:var(--bg-primary-color);border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}petshop--organism-service-highlights-102017 .service-image{width:100%;height:150px;object-fit:cover;border-radius:4px;margin-bottom:var(--space-16)}petshop--organism-service-highlights-102017 .service-name{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-8)}petshop--organism-service-highlights-102017 .service-description{font-size:var(--font-size-16);color:var(--text-primary-color-darker);margin-bottom:var(--space-16)}petshop--organism-service-highlights-102017 .service-cta{display:inline-block;padding:var(--space-16) var(--space-24);background-color:var(--text-primary-color);color:var(--bg-primary-color);text-decoration:none;font-weight:var(--font-weight-bold);border-radius:4px;transition:background-color var(--transition-normal)}petshop--organism-service-highlights-102017 .service-cta:hover{background-color:var(--text-primary-color-hover)}@media (max-width:768px){petshop--organism-service-highlights-102017 .services-grid{grid-template-columns:1fr}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        const resp = this.mockFetchServices();
        this.updateStatesFromServices(resp);
    }
    /**
     * endpoint-intent: I need an endpoint to fetch the list of highlighted services.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.services
     */
    mockFetchServices() {
        return { services: inMemoryDb.services };
    }
    updateStatesFromServices(resp) {
        setState('ui.petshop.organismServiceHighlights.services', resp);
        this.servicesResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="services-container" id="petshop--service-highlights-102017-1">
      <h2 class="services-title" id="petshop--service-highlights-102017-2">${this.i18n.title}</h2>
      <div class="services-grid" id="petshop--service-highlights-102017-3">
        ${this.servicesResponse?.services.map((service, index) => html `
          <div class="service-item" id="petshop--service-highlights-102017-${4 + index * 5}">
            <img src="${service.imageUrl}" alt="${service.name}" class="service-image" id="petshop--service-highlights-102017-${5 + index * 5}">
            <h3 class="service-name" id="petshop--service-highlights-102017-${6 + index * 5}">${service.name}</h3>
            <p class="service-description" id="petshop--service-highlights-102017-${7 + index * 5}">${service.description}</p>
            <a href="#" class="service-cta" id="petshop--service-highlights-102017-${8 + index * 5}">${this.i18n.cta}</a>
          </div>
        `)}
      </div>
    </div>`;
    }
};
__decorate([
    state()
], organismServiceHighlights.prototype, "servicesResponse", void 0);
organismServiceHighlights = __decorate([
    customElement('petshop--organism-service-highlights-102017')
], organismServiceHighlights);
export { organismServiceHighlights };
