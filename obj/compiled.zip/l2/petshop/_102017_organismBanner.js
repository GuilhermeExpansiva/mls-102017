var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="organismBanner" project="102017" folder="petshop" enhancement="_100554_enhancementLit" groupName="petshop" />
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaOrganismBase } from '_100554_icaOrganismBase';
import { setState } from '_100554_collabState';
/// **collab_i18n_start**
const message_pt = {
    bannerAlt: 'Pets felizes no petshop'
};
const message_en = {
    bannerAlt: 'Happy pets in the petshop'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const inMemoryDb = {
    content: {
        bannerUrl: "https://images.unsplash.com/photo-1760726403694-73aacccff16f?crop=entropy&amp;cs=srgb&amp;fm=jpg&amp;ixid=M3w2NDU4NjB8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZ3MlMjBhbmQlMjBjYXRzJTIwaW4lMjBhJTIwcGV0JTIwc2hvcHxlbnwwfHx8fDE3NjI3OTUwMjl8MA&amp;ixlib=rb-4.1.0&amp;q=85",
        title: "Bem-vindo ao PetShop Amigo!",
        subtitle: "Tudo para o seu pet com amor e cuidado. Descubra produtos e serviços incríveis.",
        ctaText: "Explorar Produtos",
        ctaLink: "#"
    }
};
let organismBanner = class organismBanner extends IcaOrganismBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`petshop--organism-banner-102017 .banner-container{position:relative;height:400px;background-color:var(--bg-secondary-color);display:flex;align-items:center;justify-content:center;text-align:center;overflow:hidden}petshop--organism-banner-102017 .banner-image{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:1}petshop--organism-banner-102017 .banner-overlay{position:absolute;top:0;left:0;width:100%;height:100%;background-color:rgba(0,0,0,0.4);z-index:2}petshop--organism-banner-102017 .banner-content{position:relative;z-index:3;color:var(--bg-primary-color);max-width:600px;padding:var(--space-24)}petshop--organism-banner-102017 .banner-title{font-size:var(--font-size-48);font-weight:var(--font-weight-bold);margin-bottom:var(--space-16)}petshop--organism-banner-102017 .banner-subtitle{font-size:var(--font-size-20);margin-bottom:var(--space-24)}petshop--organism-banner-102017 .banner-cta{display:inline-block;padding:var(--space-16) var(--space-32);background-color:var(--text-secondary-color);color:var(--bg-primary-color);text-decoration:none;font-weight:var(--font-weight-bold);border-radius:4px;transition:background-color var(--transition-normal)}petshop--organism-banner-102017 .banner-cta:hover{background-color:var(--text-secondary-color-hover)}@media (max-width:768px){petshop--organism-banner-102017 .banner-container{height:300px}petshop--organism-banner-102017 .banner-title{font-size:var(--font-size-40)}petshop--organism-banner-102017 .banner-subtitle{font-size:var(--font-size-16)}}`);
        this.i18n = messages['en'];
    }
    connectedCallback() {
        super.connectedCallback();
        this.updateStatesFromContent(this.mockFetchContent());
    }
    /**
     * endpoint-intent: I need an endpoint to fetch the banner content.
     * method: GET
     * notes: client-only mock, reads from inMemoryDb.content
     */
    mockFetchContent() {
        return inMemoryDb.content;
    }
    updateStatesFromContent(resp) {
        setState("ui.petshop.organismBanner", resp);
        this.contentResponse = resp;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.i18n = messages[lang];
        return html `<div class="banner-container" id="petshop--banner-102017-1">
      <img src="${this.contentResponse?.bannerUrl}" alt="${this.i18n.bannerAlt}" class="banner-image" id="petshop--banner-102017-2">
      <div class="banner-overlay" id="petshop--banner-102017-3"></div>
      <div class="banner-content" id="petshop--banner-102017-4">
        <h1 class="banner-title" id="petshop--banner-102017-5">${this.contentResponse?.title}</h1>
        <p class="banner-subtitle" id="petshop--banner-102017-6">${this.contentResponse?.subtitle}</p>
        <a href="${this.contentResponse?.ctaLink}" class="banner-cta" id="petshop--banner-102017-7">${this.contentResponse?.ctaText}</a>
      </div>
    </div>`;
    }
};
__decorate([
    state()
], organismBanner.prototype, "contentResponse", void 0);
organismBanner = __decorate([
    customElement('petshop--organism-banner-102017')
], organismBanner);
export { organismBanner };
