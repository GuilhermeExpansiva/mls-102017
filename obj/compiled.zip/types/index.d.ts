declare module "_102017_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102017_page1.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_page1" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class Page1100000 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102017_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_project" {
    export const modules: any[];
}
declare module "_102017_widget1.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_widget1" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class Widget1100000 extends StateLitElement {
        name: string;
        render(): any;
    }
}
