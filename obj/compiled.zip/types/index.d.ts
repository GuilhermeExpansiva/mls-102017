declare module "_102017_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102017_page1.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_page1" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class Page1100000 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102017_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_project" {
    export const projectConfig: {
        modules: {
            name: string;
            path: string;
            auth: string;
            icon: string;
        }[];
    };
}
declare module "_102017_widget1.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102017_widget1" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class Widget1100000 extends StateLitElement {
        name: string;
        render(): any;
    }
}
declare module "petshop/_102017_adminPanel.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102017_adminPanel.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_adminPanel" {
    import { CollabPageElement } from '_100554_collabPageElement';
    export class PageAdminPanel extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102017_blogPage.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102017_blogPage.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_blogPage" {
    import { CollabPageElement } from '_100554_collabPageElement';
    export class PageBlogPage extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102017_homePage.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102017_homePage.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_homePage" {
    import { CollabPageElement } from '_100554_collabPageElement';
    export class PageHomePage extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102017_loyaltyDashboard.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102017_loyaltyDashboard.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_loyaltyDashboard" {
    import { CollabPageElement } from '_100554_collabPageElement';
    export class PageLoyaltyDashboard extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102017_module.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: any[];
    };
    export const payload3: {
        finalModuleDetails: {
            userLanguage: string;
            executionRegions: string;
            userPrompt: string;
            moduleGoal: string;
            moduleName: string;
            requirements: string[];
            userRequestsEnhancements: {
                description: string;
                priority: string;
            }[];
        };
        pages: {
            pageSequential: number;
            pageName: string;
            pageGoal: string;
            pageRequirements: string[];
        }[];
        plugins: {
            pluginSequential: number;
            pluginName: string;
            pluginType: string;
            pluginGoal: string;
            pluginRequirements: string[];
        }[];
        pagesWireframe: {
            pageSequential: number;
            pageName: string;
            pageHtml: string[];
        }[];
        organism: ({
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                        comment: string;
                    }[];
                }[];
                constraints: string[];
            };
        } | {
            organismSequential: number;
            organismTag: string;
            planning: {
                context: string;
                goal: string;
                userStories: {
                    story: string;
                    derivedRequirements: {
                        description: string;
                        comment: string;
                    }[];
                }[];
                constraints?: undefined;
            };
        })[];
        visualIdentity: {
            logoDescription: string;
            fontFamily: string;
            iconStyle: string;
            illustrationStyle: string;
            colorPalette: {
                primary: string;
                secondary: string;
                text: string;
                background: string;
                border: string;
                error: string;
                warning: string;
                success: string;
            };
        };
        tokens: {
            description: string;
            themeName: string;
            color: {
                "text-primary-color-lighter": string;
                "text-primary-color-lighter-hover": string;
                "text-primary-color-lighter-focus": string;
                "text-primary-color-lighter-disabled": string;
                "text-primary-color": string;
                "text-primary-color-hover": string;
                "text-primary-color-focus": string;
                "text-primary-color-disabled": string;
                "text-primary-color-darker": string;
                "text-primary-color-darker-hover": string;
                "text-primary-color-darker-focus": string;
                "text-primary-color-darker-disabled": string;
                "text-secondary-color-lighter": string;
                "text-secondary-color-lighter-hover": string;
                "text-secondary-color-lighter-focus": string;
                "text-secondary-color-lighter-disabled": string;
                "text-secondary-color": string;
                "text-secondary-color-hover": string;
                "text-secondary-color-focus": string;
                "text-secondary-color-disabled": string;
                "text-secondary-color-darker": string;
                "text-secondary-color-darker-hover": string;
                "text-secondary-color-darker-focus": string;
                "text-secondary-color-darker-disabled": string;
                "bg-primary-color-lighter": string;
                "bg-primary-color-lighter-hover": string;
                "bg-primary-color-lighter-focus": string;
                "bg-primary-color-lighter-disabled": string;
                "bg-primary-color": string;
                "bg-primary-color-hover": string;
                "bg-primary-color-focus": string;
                "bg-primary-color-disabled": string;
                "bg-primary-color-darker": string;
                "bg-primary-color-darker-hover": string;
                "bg-primary-color-darker-focus": string;
                "bg-primary-color-darker-disabled": string;
                "bg-secondary-color-lighter": string;
                "bg-secondary-color-lighter-hover": string;
                "bg-secondary-color-lighter-focus": string;
                "bg-secondary-color-lighter-disabled": string;
                "bg-secondary-color": string;
                "bg-secondary-color-hover": string;
                "bg-secondary-color-focus": string;
                "bg-secondary-color-disabled": string;
                "bg-secondary-color-darker": string;
                "bg-secondary-color-darker-hover": string;
                "bg-secondary-color-darker-focus": string;
                "bg-secondary-color-darker-disabled": string;
                "grey-color-lighter": string;
                "grey-color-light": string;
                "grey-color": string;
                "grey-color-dark": string;
                "grey-color-darker": string;
                "error-color": string;
                "error-color-hover": string;
                "error-color-focus": string;
                "error-color-disabled": string;
                "success-color": string;
                "success-color-hover": string;
                "success-color-focus": string;
                "success-color-disabled": string;
                "warning-color": string;
                "warning-color-hover": string;
                "warning-color-focus": string;
                "warning-color-disabled": string;
                "info-color": string;
                "info-color-hover": string;
                "info-color-focus": string;
                "info-color-disabled": string;
                "active-color": string;
                "active-color-hover": string;
                "active-color-focus": string;
                "active-color-disabled": string;
                "link-color": string;
                "link-color-hover": string;
                "link-color-focus": string;
                "link-color-disabled": string;
                "_dark-text-primary-color-lighter": string;
                "_dark-text-primary-color-lighter-hover": string;
                "_dark-text-primary-color-lighter-focus": string;
                "_dark-text-primary-color-lighter-disabled": string;
                "_dark-text-primary-color": string;
                "_dark-text-primary-color-hover": string;
                "_dark-text-primary-color-focus": string;
                "_dark-text-primary-color-disabled": string;
                "_dark-text-primary-color-darker": string;
                "_dark-text-primary-color-darker-hover": string;
                "_dark-text-primary-color-darker-focus": string;
                "_dark-text-primary-color-darker-disabled": string;
                "_dark-text-secondary-color-lighter": string;
                "_dark-text-secondary-color-lighter-hover": string;
                "_dark-text-secondary-color-lighter-focus": string;
                "_dark-text-secondary-color-lighter-disabled": string;
                "_dark-text-secondary-color": string;
                "_dark-text-secondary-color-hover": string;
                "_dark-text-secondary-color-focus": string;
                "_dark-text-secondary-color-disabled": string;
                "_dark-text-secondary-color-darker": string;
                "_dark-text-secondary-color-darker-hover": string;
                "_dark-text-secondary-color-darker-focus": string;
                "_dark-text-secondary-color-darker-disabled": string;
                "_dark-bg-primary-color-lighter": string;
                "_dark-bg-primary-color-lighter-hover": string;
                "_dark-bg-primary-color-lighter-focus": string;
                "_dark-bg-primary-color-lighter-disabled": string;
                "_dark-bg-primary-color": string;
                "_dark-bg-primary-color-hover": string;
                "_dark-bg-primary-color-focus": string;
                "_dark-bg-primary-color-disabled": string;
                "_dark-bg-primary-color-darker": string;
                "_dark-bg-primary-color-darker-hover": string;
                "_dark-bg-primary-color-darker-focus": string;
                "_dark-bg-primary-color-darker-disabled": string;
                "_dark-bg-secondary-color-lighter": string;
                "_dark-bg-secondary-color-lighter-hover": string;
                "_dark-bg-secondary-color-lighter-focus": string;
                "_dark-bg-secondary-color-lighter-disabled": string;
                "_dark-bg-secondary-color": string;
                "_dark-bg-secondary-color-hover": string;
                "_dark-bg-secondary-color-focus": string;
                "_dark-bg-secondary-color-disabled": string;
                "_dark-bg-secondary-color-darker": string;
                "_dark-bg-secondary-color-darker-hover": string;
                "_dark-bg-secondary-color-darker-focus": string;
                "_dark-bg-secondary-color-darker-disabled": string;
                "_dark-grey-color-lighter": string;
                "_dark-grey-color-light": string;
                "_dark-grey-color": string;
                "_dark-grey-color-dark": string;
                "_dark-grey-color-darker": string;
                "_dark-error-color": string;
                "_dark-error-color-hover": string;
                "_dark-error-color-focus": string;
                "_dark-error-color-disabled": string;
                "_dark-success-color": string;
                "_dark-success-color-hover": string;
                "_dark-success-color-focus": string;
                "_dark-success-color-disabled": string;
                "_dark-warning-color": string;
                "_dark-warning-color-hover": string;
                "_dark-warning-color-focus": string;
                "_dark-warning-color-disabled": string;
                "_dark-info-color": string;
                "_dark-info-color-hover": string;
                "_dark-info-color-focus": string;
                "_dark-info-color-disabled": string;
                "_dark-active-color": string;
                "_dark-active-color-hover": string;
                "_dark-active-color-focus": string;
                "_dark-active-color-disabled": string;
                "_dark-link-color": string;
                "_dark-link-color-hover": string;
                "_dark-link-color-focus": string;
                "_dark-link-color-disabled": string;
            };
            global: {
                "breakpoint-small": string;
                "breakpoint-medium": string;
                "breakpoint-large": string;
                "transition-slow": string;
                "transition-normal": string;
                "transition-fast": string;
                "space-base-unit": string;
                "space-8": string;
                "space-16": string;
                "space-24": string;
                "space-32": string;
                "space-40": string;
                "space-48": string;
                "space-64": string;
            };
            typography: {
                "font-base-unit": string;
                "font-family-primary": string;
                "font-family-secondary": string;
                "font-size-12": string;
                "font-size-16": string;
                "font-size-20": string;
                "font-size-24": string;
                "font-size-40": string;
                "font-size-48": string;
                "font-size-64": string;
                "line-height-base-unit": string;
                "line-height-small": string;
                "line-height-medium": string;
                "line-height-large": string;
                "font-weight-lighter": string;
                "font-weight-light": string;
                "font-weight-normal": string;
                "font-weight-bold": string;
                "font-weight-bolder": string;
            };
        };
        obs: any[];
    };
}
declare module "petshop/_102017_organismAdminMenu.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismAdminMenu.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismAdminMenu" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface MenuItem {
        id: number;
        labelKey: string;
        href: string;
        visible: boolean;
    }
    interface AdminMenuResponse {
        items: MenuItem[];
    }
    export class organismAdminMenu extends IcaOrganismBase {
        private i18n;
        adminMenuResponse?: AdminMenuResponse;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the admin menu items based on user permissions.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.adminMenu
         */
        private mockFetchAdminMenu;
        private updateStatesFromAdminMenu;
        render(): any;
    }
}
declare module "petshop/_102017_organismBanner.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: string[];
        };
    };
}
declare module "petshop/_102017_organismBanner.test" {
    import { ICANTest, ICANIntegration } from '_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismBanner" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface ContentResponse {
        bannerUrl: string;
        title: string;
        subtitle: string;
        ctaText: string;
        ctaLink: string;
    }
    export class organismBanner extends IcaOrganismBase {
        contentResponse?: ContentResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the banner content.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.content
         */
        private mockFetchContent;
        private updateStatesFromContent;
        render(): any;
    }
}
declare module "petshop/_102017_organismBlogList.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismBlogList.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismBlogList" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface BlogPost {
        id: string;
        imageUrl: string;
        altText: string;
        title: string;
        summary: string;
    }
    type ContentResponse = BlogPost[];
    export class organismBlogList extends IcaOrganismBase {
        contentResponse?: ContentResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the list of blog posts.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.blogPosts
         */
        private mockFetchBlogPosts;
        private updateStatesFromContent;
        render(): any;
    }
}
declare module "petshop/_102017_organismBlogPost.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismBlogPost.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismBlogPost" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface BlogPostResponse {
        title: string;
        meta: string;
        imageUrl: string;
        imageAlt: string;
        content: {
            intro: string;
            nutrition: {
                title: string;
                text: string;
            };
            exercise: {
                title: string;
                text: string;
            };
            care: {
                title: string;
                text: string;
            };
            reminder: string;
        };
        shareButtons: {
            facebook: string;
            twitter: string;
            whatsapp: string;
        };
        comments: Array<{
            author: string;
            text: string;
        }>;
    }
    export class organismBlogPost extends IcaOrganismBase {
        contentResponse?: BlogPostResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the blog post content.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.blogPost
         */
        private mockFetchBlogPost;
        private updateStatesFromContent;
        render(): any;
    }
}
declare module "petshop/_102017_organismCalendar.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismCalendar.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismCalendar" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface AvailabilityResponse {
        dates: number[];
        times: string[];
    }
    export class organismCalendar extends IcaOrganismBase {
        availabilityResponse?: AvailabilityResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch available dates and times for scheduling.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.availability
         */
        private mockFetchAvailability;
        private updateStatesFromAvailability;
        render(): any;
    }
}
declare module "petshop/_102017_organismConfirmation.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismConfirmation.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismConfirmation" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface AppointmentResponse {
        service: string;
        date: string;
        time: string;
        price: string;
    }
    export class organismConfirmation extends IcaOrganismBase {
        appointmentResponse?: AppointmentResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the current appointment details for confirmation.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.appointment
         */
        private mockFetchAppointment;
        private updateStatesFromAppointment;
        render(): any;
    }
}
declare module "petshop/_102017_organismDashboardStats.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismDashboardStats.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismDashboardStats" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface StatsResponse {
        totalSales: number;
        todayAppointments: number;
        activeClients: number;
        stockProducts: number;
    }
    export class organismDashboardStats extends IcaOrganismBase {
        statsResponse?: StatsResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch dashboard statistics.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.stats
         */
        private mockFetchStats;
        private updateStatesFromStats;
        render(): any;
    }
}
declare module "petshop/_102017_organismFilters.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismFilters.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismFilters" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface AppliedFilters {
        category: string;
        minPrice: number;
        maxPrice: number;
    }
    export class organismFilters extends IcaOrganismBase {
        private i18n;
        appliedFilters?: AppliedFilters;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch available filter options for products.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.filters
         */
        private mockFetchFilters;
        /**
         * endpoint-intent: I need an endpoint to apply filters and retrieve filtered products.
         * method: POST
         * notes: client-only mock, updates inMemoryDb and simulates filtering
         */
        private mockApplyFilters;
        private updateStatesFromFilters;
        private handleApplyFilters;
        render(): any;
    }
}
declare module "petshop/_102017_organismFooter.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismFooter.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismFooter" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface FooterResponse {
        contact: {
            phone: string;
            email: string;
            address: string;
        };
        usefulLinks: Array<{
            text: string;
            href: string;
        }>;
        socialNetworks: Array<{
            icon: string;
            href: string;
        }>;
        copyright: string;
    }
    export class organismFooter extends IcaOrganismBase {
        footerResponse?: FooterResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch footer content.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.footer
         */
        private mockFetchFooter;
        private updateStatesFromFooter;
        render(): any;
    }
}
declare module "petshop/_102017_organismManageProducts.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismManageProducts.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismManageProducts" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface Product {
        id: number;
        name: string;
        category: string;
        price: number;
        stock: number;
    }
    interface ProductsResponse {
        products: Product[];
    }
    export class organismManageProducts extends IcaOrganismBase {
        productsResponse?: ProductsResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: preciso de um endpoint para buscar a lista de produtos
         * method: GET
         * notes: usado por este organismo para listar produtos na tela
         */
        private mockFetchProducts;
        private updateStatesFromProducts;
        render(): any;
    }
}
declare module "petshop/_102017_organismNav.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: string[];
        };
    };
}
declare module "petshop/_102017_organismNav.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismNav" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface NavData {
        logo: string;
        menuItems: {
            icon: string;
            text: string;
            href: string;
        }[];
    }
    export class organismNav extends IcaOrganismBase {
        navData?: NavData;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch navigation data for the petshop site.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.nav
         */
        private mockFetchNavData;
        private updateStatesFromNav;
        render(): any;
    }
}
declare module "petshop/_102017_organismPointsBalance.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismPointsBalance.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismPointsBalance" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface PointsResponse {
        points: number;
    }
    export class organismPointsBalance extends IcaOrganismBase {
        pointsResponse?: PointsResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the user's loyalty points balance.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.points
         */
        private mockFetchPoints;
        private updateStatesFromPoints;
        render(): any;
    }
}
declare module "petshop/_102017_organismProductCategories.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismProductCategories.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismProductCategories" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface Category {
        id: number;
        name: string;
        imageUrl: string;
        alt: string;
        link: string;
    }
    interface CategoriesResponse {
        categories: Category[];
    }
    export class organismProductCategories extends IcaOrganismBase {
        private i18n;
        categoriesResponse?: CategoriesResponse;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch product categories.
         * method: GET
         * notes: used by this organism to populate the categories list.
         */
        private mockFetchCategories;
        private updateStatesFromCategories;
        render(): any;
    }
}
declare module "petshop/_102017_organismProductList.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismProductList.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismProductList" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface Product {
        id: number;
        name: string;
        price: string;
        image: string;
        alt: string;
    }
    interface ProductsResponse {
        products: Product[];
    }
    export class organismProductList extends IcaOrganismBase {
        private i18n;
        productsResponse?: ProductsResponse;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the list of products.
         * method: GET
         * notes: used by this organism to populate the product list.
         */
        private mockFetchProducts;
        private updateStatesFromProducts;
        render(): any;
    }
}
declare module "petshop/_102017_organismRedeemForm.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismRedeemForm.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismRedeemForm" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface RedeemResponse {
        rewards: Array<{
            id: string;
            name: string;
            points: number;
        }>;
        userBalance: number;
    }
    export class organismRedeemForm extends IcaOrganismBase {
        redeemResponse?: RedeemResponse;
        private i18n;
        connectedCallback(): void;
        render(): any;
        /**
         * endpoint-intent: I need an endpoint to fetch available rewards and user balance.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb
         */
        private mockFetchRedeemData;
        /**
         * endpoint-intent: I need an endpoint to process reward redemption.
         * method: POST
         * notes: client-only mock, updates inMemoryDb and state
         */
        private mockRedeemReward;
        private updateStatesFromRedeem;
        private handleSubmit;
    }
}
declare module "petshop/_102017_organismRewardsList.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismRewardsList.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismRewardsList" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface Reward {
        id: string;
        imageUrl: string;
        altText: string;
        title: string;
        cost: number;
    }
    interface RewardsResponse {
        rewards: Reward[];
    }
    export class organismRewardsList extends IcaOrganismBase {
        private i18n;
        rewardsResponse?: RewardsResponse;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch available rewards for redemption.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.rewards
         */
        private mockFetchRewards;
        private updateStatesFromRewards;
        render(): any;
    }
}
declare module "petshop/_102017_organismServiceHighlights.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismServiceHighlights.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismServiceHighlights" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface Service {
        name: string;
        description: string;
        imageUrl: string;
    }
    interface ServicesResponse {
        services: Service[];
    }
    export class organismServiceHighlights extends IcaOrganismBase {
        servicesResponse?: ServicesResponse;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch the list of highlighted services.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.services
         */
        private mockFetchServices;
        private updateStatesFromServices;
        render(): any;
    }
}
declare module "petshop/_102017_organismServiceSelection.defs" {
    export const defs: {
        meta: {
            projectId: number;
            folder: string;
            shortName: string;
            type: string;
            devFidelity: string;
            group: string;
            tags: string[];
        };
        references: {
            widgets: any[];
            plugins: any[];
            statesRO: any[];
            statesRW: any[];
            statesWO: any[];
            imports: any[];
        };
        planning: {
            generalDescription: string;
            goal: string;
            userStories: {
                story: string;
                derivedRequirements: {
                    description: string;
                    comment: string;
                }[];
            }[];
            userRequestsEnhancements: any[];
            constraints: any[];
        };
    };
}
declare module "petshop/_102017_organismServiceSelection.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_organismServiceSelection" {
    import { IcaOrganismBase } from '_100554_icaOrganismBase';
    interface Service {
        id: string;
        name: string;
        description: string;
        price: string;
        iconUrl: string;
    }
    interface ServicesResponse {
        services: Service[];
    }
    export class organismServiceSelection extends IcaOrganismBase {
        servicesResponse?: ServicesResponse;
        selectedServiceId?: string;
        private i18n;
        connectedCallback(): void;
        /**
         * endpoint-intent: I need an endpoint to fetch available services for selection.
         * method: GET
         * notes: client-only mock, reads from inMemoryDb.services
         */
        private mockFetchServices;
        private updateStatesFromServices;
        private selectService;
        render(): any;
    }
}
declare module "petshop/_102017_productCatalog.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102017_productCatalog.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_productCatalog" {
    import { CollabPageElement } from '_100554_collabPageElement';
    export class PageProductCatalog extends CollabPageElement {
        initPage(): void;
    }
}
declare module "petshop/_102017_serviceScheduling.defs" {
    export const defs: mls.l4.BaseDefs;
}
declare module "petshop/_102017_serviceScheduling.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "petshop/_102017_serviceScheduling" {
    import { CollabPageElement } from '_100554_collabPageElement';
    export class PageServiceScheduling extends CollabPageElement {
        initPage(): void;
    }
}
